//
//  GlobalConstants.swift
//  Gilim
//
//  Created by Felipe Cueto Ramirez on 3/10/17.
//  Copyright © 2017 isis3510. All rights reserved.
//

import Foundation

struct  ConstanstSegmented {
    let url = URL(string:"http://demo9177756.mockable.io/")!
    let creidfot = 1

}
