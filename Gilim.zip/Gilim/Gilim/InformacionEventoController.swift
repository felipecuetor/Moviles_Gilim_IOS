//
//  InformacionEventoController.swift
//  Gilim
//
//  Created by Felipe Cueto Ramirez on 3/9/17.
//  Copyright © 2017 isis3510. All rights reserved.
//

import Foundation
